console.log("hello world");
console.log("hi hello");
console.log("Jai ho");
console.log("hello");
console.log("hi");
console.log("jai ho");