let lname = "rahul";
//lname =10;
let newname =lname.toUpperCase();
console.log(newname);


const enum color{
    Red,
    Green,
    Blue
}
let c: color =color.Blue;
