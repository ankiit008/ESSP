"use strict";
let lname = "rahul";
//lname =10;
let newname = lname.toUpperCase();
console.log(newname);
let c = 2 /* color.Blue */;
